import asyncio
import os
import sys

# resolve the plugin directory from this file's location, as the loader
# process's working directory is not the plugin directory
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from decky import logger
from py_modules.deal_db import DealDB
from py_modules.plugin_settings import settingsManager, SETTINGS_DEFAULTS


class Plugin:
    async def _main(self):
        try:
            # check settings for validity, if a setting is malformed then set it to default
            for key, value in SETTINGS_DEFAULTS.items():
                setting = await self.settings_getSetting(key)
                if setting is None:
                    logger.info(f"Setting {key} is malformed...resetting to default.")
                    await self.settings_setSetting(key, value)
        except Exception as e:
            logger.exception(e)
            raise e

    async def _unload(self):
        logger.info("Unloading Free Loader")

    async def update_deals_now(self):
        try:
            dealdb = DealDB()
            # run in a thread so the slow network request does not block
            # other plugin methods on the event loop
            await asyncio.to_thread(dealdb.process_new_deals)
            return dealdb.num_new_deals
        except Exception as e:
            logger.exception(e)
            raise e

    async def read_deals(self) -> dict:
        try:
            logger.info("Reading deals from local json")
            dealdb = DealDB()
            dealdb.import_from_json()
            return dealdb.to_dict()
        except Exception as e:
            logger.exception(e)
            raise e

    async def clear_deals(self) -> dict:
        try:
            dealdb = DealDB()
            dealdb.export_to_json()
            logger.info("Cleared game database")
            return dealdb.to_dict()
        except Exception as e:
            logger.exception(e)
            raise e

    async def toggle_deal_visibility(self, id: str) -> dict:
        try:
            dealdb = DealDB()
            is_hidden = dealdb.toggle_deal_visibility(id)
            logger.info(f"Game id {id} hidden: {is_hidden}")
            return {"hidden": is_hidden}
        except Exception as e:
            logger.exception(e)
            raise e

    async def settings_read(self) -> dict:
        logger.info("Reading all settings")
        return {
            key.value: settingsManager.getSetting(key, default)
            for key, default in SETTINGS_DEFAULTS.items()
        }

    async def settings_commit(self):
        logger.info("Saving settings")
        return settingsManager.commit()

    async def settings_getSetting(self, key: str):
        logger.debug("Get {}".format(key))
        return settingsManager.getSetting(key, None)

    async def settings_setSetting(self, key: str, value):
        logger.debug("Set {}: {}".format(key, value))
        return settingsManager.setSetting(key, value)

    async def settings_restoreSettings(self):
        for key, value in SETTINGS_DEFAULTS.items():
            settingsManager.setSetting(key, value)
        logger.info("Restored settings to defaults")
        return settingsManager.commit()

    async def logger_info(self, info):
        logger.info(info)

    async def logger_error(self, error):
        logger.error(error)
