# PlayTime

<div align="center">

  [![License](https://img.shields.io/badge/license-GPL--3.0--or--later-blue)](LICENSE)
  ![Testing store Downloads](https://img.shields.io/badge/dynamic/json?url=https://testing.deckbrew.xyz/plugins?query=PlayTime&query=$[:1].downloads&suffix=%20installs&label=Testing%20store)
  ![Testing store Updates](https://img.shields.io/badge/dynamic/json?url=https://testing.deckbrew.xyz/plugins?query=PlayTime&query=$[:1].updates&suffix=%20updates&label=Testing%20store)
  ![Stable store Downloads](https://img.shields.io/badge/dynamic/json?url=https://plugins.deckbrew.xyz/plugins?query=PlayTime&query=$[:1].downloads&suffix=%20installs&label=Stable%20store)
  ![Stable store Updates](https://img.shields.io/badge/dynamic/json?url=https://plugins.deckbrew.xyz/plugins?query=PlayTime&query=$[:1].updates&suffix=%20updates&label=Stable%20store)

</div>

<div align="center">

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/ynhhoj)

</div>

![PlayTime Logo](https://raw.githubusercontent.com/0u73r-h34v3n/PlayTime/refs/heads/master/assets/image.png)

PlayTime is a plugin for the SteamDeck gaming console, designed to track the amount of time you spend playing games. It provides weekly and monthly reports, as well as an overall summary of your gaming time. In addition, it offers data migration from the SteamLessTimes and MetaDeck plugins. PlayTime also allows you to manually adjust your overall playtime through the settings.

## Installation

The best way to get plugin is to use official Decky Plugin Store (https://plugins.deckbrew.xyz/).

To install PlayTime manually:

1. Go to the [PlayTime GitHub repository](https://github.com/your-username/PlayTime).
2. Download the latest release package (ZIP format).
3. Copy the zip file to SteamDeck and install it from Decky loader.

Alternatively, you can build PlayTime from source by following these steps:

1. Clone the PlayTime repository:
   ```shell
   git clone git@github.com:0u73r-h34v3n/SDH-PlayTime.git
   ```

2. Navigate to the project directory:
   ```shell
   cd SDH-PlayTime
   ```

3. If you want to deploy the plugin directly to the Deck, use the following command instead:
   ```shell
   make deploy
   ```

   Make sure your SteamDeck is connected and properly set up for development.

## Development Requirements

To contribute or modify PlayTime, ensure you have the following requirements installed:

* pnpm version 9.x.x or higher

You can install `pnpm` by following the instructions in the [pnpm GitHub repository](https://github.com/pnpm/pnpm).

## Usage

Once PlayTime is installed on your SteamDeck, it will automatically start tracking your game playtime. You can access the plugin by launching the Decky Plugin Loader and selecting PlayTime from the list of installed plugins.

The main features of PlayTime include:

* Weekly and monthly reports: Get insights into your gaming habits over different time periods.
* Overall summary: View your total playtime across all games.
* Data migration: Import your playtime data from other plugins, such as SteamLessTimes and MetaDeck.
* Manual playtime adjustment: If needed, you can manually change your overall playtime through the settings.

## Contributing

Contributions to PlayTime are welcome! If you would like to contribute, please follow these steps:

1. Fork the PlayTime repository.
2. Create a new branch for your feature or bug fix.
3. Make the necessary changes in your branch.
4. Commit your changes and push them to your fork.
5. Submit a pull request to the main PlayTime repository.

Please ensure your code follows the project's coding conventions and includes appropriate tests.

## Acknowledgements

We would like to thank the contributors and supporters of PlayTime for their valuable contributions and feedback.

Special thanks to the Decky Plugin Loader project for providing the infrastructure and support for developing plugins on the SteamDeck console.

## Contact

If you have any questions, suggestions, or need assistance with PlayTime, feel free to contact us at 
Discord [PlayTime support thread](https://discord.com/channels/960281551428522045/1087800823846813716) in official [Decky Loader 
Discord](https://discord.com/invite/U88fbeHyzt) server
We appreciate your feedback!

Happy gaming with **PlayTime**!
