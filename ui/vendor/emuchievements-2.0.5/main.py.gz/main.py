import asyncio
import json
import logging
import math
import os

import decky_plugin

logger = logging.getLogger("Emuchievements")
logger.setLevel(logging.INFO)


class Plugin:
	packet_size: int = 1000
	length: int = 0
	buffer: str = ""
	async def start_write_config(self, length, packet_size = 1000) -> None:
		Plugin.buffer = ""
		Plugin.length = length
		Plugin.packet_size = packet_size

	async def write_config(self, index, data) -> None:
		Plugin.buffer += data
		if index >= Plugin.length - 1:
			Plugin.length = 0
			config = json.loads(Plugin.buffer)
			Plugin.buffer = ""
			with open(os.path.join(decky_plugin.DECKY_PLUGIN_SETTINGS_DIR, "settings.json"), "w") as f:
				json.dump(config, f, indent="\t")

	async def start_read_config(self, packet_size = 1000) -> int:
		Plugin.buffer = ""
		Plugin.length = 0
		Plugin.packet_size = packet_size
		with open(os.path.join(decky_plugin.DECKY_PLUGIN_SETTINGS_DIR, "settings.json"), "r") as f:
			config = json.load(f)
			Plugin.buffer = json.dumps(config, indent="\t")
			Plugin.length = math.ceil(len(Plugin.buffer) / float(Plugin.packet_size))
			return Plugin.length

	async def read_config(self, index) -> str:
		if index < Plugin.length - 1:
			return Plugin.buffer[index * Plugin.packet_size : (index + 1) * Plugin.packet_size]
		else:
			Plugin.length = 0
			config =  Plugin.buffer[index * Plugin.packet_size :]
			Plugin.buffer = ""
			return config

	async def hash(self, path: str) -> str:
		if not isinstance(path, str) or not path or "\0" in path:
			raise ValueError("Invalid ROM path")
		helper = os.path.join(decky_plugin.DECKY_PLUGIN_DIR, "bin", "hash")
		process = await asyncio.create_subprocess_exec(
			helper, path, stdout=asyncio.subprocess.PIPE,
			stderr=asyncio.subprocess.DEVNULL)
		try:
			output, _ = await asyncio.wait_for(process.communicate(), timeout=120)
		except asyncio.TimeoutError:
			process.kill()
			await process.wait()
			raise
		if process.returncode != 0:
			raise RuntimeError("ROM hash helper failed")
		result = output.decode("ascii").strip()
		if len(result) != 32 or any(c not in "0123456789abcdef" for c in result):
			raise RuntimeError("Invalid ROM hash result")
		return result

	async def reset(self) -> None:
		Plugin.length = 0
		Plugin.buffer = ""
		Plugin.packet_size = 1000

	# Asyncio-compatible long-running code, executed in a task when the plugin is loaded
	async def _main(self):
		if not os.path.exists(os.path.join(decky_plugin.DECKY_PLUGIN_SETTINGS_DIR, "settings.json")):
			with open(os.path.join(decky_plugin.DECKY_PLUGIN_SETTINGS_DIR, "settings.json"), "w") as f:
				json.dump({
					"username": "",
					"api_key": "",
					"cache": {
						"ids": {}
					},
					"hidden": False
				}, f, indent="\t")


	async def _unload(self):
		pass

	async def _migration(self):
		decky_plugin.migrate_settings(
			os.path.join(decky_plugin.DECKY_HOME, "settings", "emuchievements.json"))
		if os.path.exists(os.path.join(decky_plugin.DECKY_PLUGIN_SETTINGS_DIR, "emuchievements.json")):
			os.rename(os.path.join(decky_plugin.DECKY_PLUGIN_SETTINGS_DIR, "emuchievements.json"),
					os.path.join(decky_plugin.DECKY_PLUGIN_SETTINGS_DIR, "settings.json"))
