import hashlib
import json
from pathlib import Path
import subprocess

command = ['/input/py-spy', 'record', '--subprocesses', '--threads', '--rate', '50',
           '--format', 'raw', '--nonblocking', '--output', '/tmp/owned-parent-eof-stacks.raw',
           '--', 'python3', '/input/probe.py']
report = dict(samplerSha256=hashlib.sha256(Path('/input/py-spy').read_bytes()).hexdigest(),
              command=command, probeSha256=hashlib.sha256(Path('/input/probe.py').read_bytes()).hexdigest(), probeSubreaperEnabled=True, realFrameContacted=False, historicalCauseEstablished=False,
              releaseHoldCleared=False, nonblockingSampling=True, addedCapabilities=False)
try:
    result = subprocess.run(command, capture_output=True, text=True, timeout=85)
    report.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    path = Path('/tmp/owned-parent-eof-stacks.raw')
    if path.exists():
        data = path.read_bytes()
        report.update(stackBytes=len(data), stackSha256=hashlib.sha256(data).hexdigest(),
                      stackText=data[:1048576].decode(errors='replace'), truncated=len(data)>1048576)
except subprocess.TimeoutExpired as exc:
    report.update(timedOut=True, stdout=(exc.stdout or b'').decode(errors='replace'),
                  stderr=(exc.stderr or b'').decode(errors='replace'))
finally:
    print('TRACE_REPORT '+json.dumps(report), flush=True)
